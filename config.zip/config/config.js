module.exports = {
    signInPath : "http://117.16.231.66:1337/signIn",
    signUpPath : "http://117.16.231.66:1337/signUp"
}